package api;

import org.junit.jupiter.api.Test;

import java.util.Collection;
import java.util.Iterator;

import static org.junit.jupiter.api.Assertions.*;

class DWGraph_DSTest extends Node {

    @Test
    void getNode() {
        DWGraph_DS g = new DWGraph_DS();
        g.addNode(new Node(5));
        g.addNode(new Node(1));
        int s = g.nodeSize();
        assertEquals(2,s);
        g.addNode(new Node(9));
        g.addNode(new Node(8));
        int x = g.nodeSize();
        assertEquals(4,x);
        g.removeNode(9);
        int z = g.nodeSize();
        assertNotEquals(4,z);
        assertEquals(3,z);
        assertNull( g.getNode(20));


    }
    @Test
    void getEdge() {
        DWGraph_DS g = new DWGraph_DS();
        assertNull(g.getEdge(5,6));
        g.addNode(new Node(0));
        g.addNode(new Node(1));
        g.addNode(new Node(2));
        g.addNode(new Node(3));
        g.connect(0,1,1);
        edge_data check=new Edge(0,1,1);
        assertEquals(check,g.getEdge(0,1));


    }

    @Test
    void addNode() {
        DWGraph_DS g = new DWGraph_DS();
        g.addNode(new Node(5));
        g.addNode(new Node(1));
        assertTrue(g.nodeSize()==2);
        g.addNode(new Node(9));
        g.addNode(new Node(8));
        assertFalse(g.nodeSize()==2);
        assertTrue(g.nodeSize()==4);

    }
    @Test
    void connect() {
        DWGraph_DS g = new DWGraph_DS();
        Node src=new Node(0);
        Node des=new Node(1);
        g.addNode(src);
        g.addNode(des);
        g.connect(src.getKey(),des.getKey(),2);
        edge_data edge=new Edge(src.getKey(),des.getKey(),2);
        assertEquals(edge.getWeight(),g.getEdge(src.getKey(),des.getKey()).getWeight());
    }

    @Test
    void getV() {
        DWGraph_DS g = new DWGraph_DS();
        g.addNode(new Node(0));
        g.addNode(new Node(1));
        g.addNode(new Node(2));
        g.addNode(new Node(3));
        g.connect(0,1,1);
        g.connect(0,2,2);
        g.connect(0,3,3);
        g.connect(0,1,1);
        Collection<node_data> v = g.getV();
        Iterator<node_data> iter = v.iterator();
        while (iter.hasNext()) {
            node_data n = iter.next();
            assertNotNull(n);
        }

    }

    @Test
    void getE() {
        DWGraph_DS g = new DWGraph_DS();
        node_data n1=new Node(0);
        node_data n2=new Node(5);
        node_data n3=new Node(9);

        g.addNode(n1);
        g.addNode(n2);
        g.addNode(n3);
        g.connect(0,5,1);
        g.connect(0,9,2);
        Collection<edge_data> v = g.getE(n1.getKey());
        Iterator<edge_data> iter = v.iterator();
        while (iter.hasNext()) {
            edge_data n = iter.next();
            assertNotNull(n);
        }

    }

    @Test
    void removeNode() {
        DWGraph_DS g = new DWGraph_DS();
        g.addNode(new Node(0));
        g.addNode(new Node(1));
        g.addNode(new Node(2));
        g.addNode(new Node(3));
        g.removeNode(0);
        assertTrue(g.nodeSize()==3);

    }

    @Test
    void removeEdge() {
        DWGraph_DS g = new DWGraph_DS();
        assertTrue(g.edgeSize()==0);
        g.addNode(new Node(0));
        g.addNode(new Node(1));
        g.addNode(new Node(2));
        g.addNode(new Node(3));
        g.connect(0,1,1);
        g.connect(0,2,1);
        assertTrue(g.edgeSize()==2);
        g.removeEdge(0,1);
        assertTrue(g.edgeSize()==1);


    }

    @Test
    void nodeSize() {
        DWGraph_DS g = new DWGraph_DS();
        g.addNode(new Node(0));
        g.addNode(new Node(2));
        g.removeNode(2);
        int s = g.nodeSize();
        assertEquals(1,s);
        g.addNode(new Node(8));
        g.addNode(new Node(9));
        int h = g.nodeSize();
        assertNotEquals(1,h);
        assertEquals(3,h);

    }

    @Test
    void edgeSize() {
        DWGraph_DS g = new DWGraph_DS();
        assertTrue(g.edgeSize()==0);
        g.addNode(new Node(0));
        g.addNode(new Node(1));
        g.addNode(new Node(2));
        g.addNode(new Node(3));
        g.connect(0,1,1);
        assertTrue(g.edgeSize()==1);

    }

}