package api;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class NodeTest extends Node {

    @Test
    void testGetKey() {
        directed_weighted_graph g=new DWGraph_DS();
        assertEquals(g.getNode(5),null);
        int x=9;
        node_data n=new Node(5);
        g.addNode(n);
        assertNotEquals(g.getNode(5).getKey(),x);
    }
    @Test
    void testGetLocation()
    {

    }



}