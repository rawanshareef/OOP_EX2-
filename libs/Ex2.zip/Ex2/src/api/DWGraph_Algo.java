package api;

import com.google.gson.Gson;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;

public class DWGraph_Algo implements dw_graph_algorithms {
    private directed_weighted_graph g;
    /**
     * Init the graph on which this set of algorithms operates on.
     * @param g
     */
    @Override
    public void init(directed_weighted_graph g) {
             this.g=g;

    }
    /**
     * Return the underlying graph of which this class works.
     * @return
     */
    @Override
    public directed_weighted_graph getGraph() {
        return this.g;
    }
    /**
     * Compute a deep copy of this weighted graph.
     * @return
     */
    @Override
    public directed_weighted_graph copy() {
        directed_weighted_graph paste = new DWGraph_DS();
        for (node_data present : g.getV()) {
            paste.addNode(present);
        }
        for (node_data present : g.getV()) {
            for (edge_data my_edge : g.getE(present.getKey())) {

                paste.connect(my_edge.getSrc(), my_edge.getDest(),my_edge.getWeight());
            }
        }
        return paste;
    }

    private void reset_tag_to0(directed_weighted_graph g) {//reset tage for all vertex to zero
        for (node_data n : g.getV()) {
            n.setTag(0);
        }
    }

    private directed_weighted_graph revers(directed_weighted_graph graph){
        directed_weighted_graph new_g = new DWGraph_DS();
        for (node_data present : g.getV()) {
            new_g.addNode(present);
        }
        for (node_data present : g.getV()) {
            for (edge_data my_edge : g.getE(present.getKey())) {
                new_g.connect( my_edge.getDest(),my_edge.getSrc(),my_edge.getWeight());
            }
        }
        return new_g;
    }
    /**
     * Returns true if and only if (iff) there is a valid path from each node to each
     * other node. NOTE: assume directional graph (all n*(n-1) ordered pairs).
     * @return
     */
    @Override
    public boolean isConnected() {
        if (g.getV().isEmpty() || g.getV().size() == 1) {//if the graph empty or contain only one node
            return true;
        } else {//the graph not empty
            directed_weighted_graph new_g = revers(g);
            reset_tag_to0(g);
            reset_tag_to0(new_g);
            node_data first = g.getV().iterator().next();
            node_data q1_first = first;
            Queue<node_data> queue = new LinkedList<>();
            queue.add(first);
            while (!queue.isEmpty()) {
                first = queue.poll();
                first.setTag(2);
                for (edge_data s : g.getE(first.getKey())) {
                    node_data check = g.getNode(s.getDest());
                    if (check.getTag() == 0) {
                        queue.add(check);
                        s.setTag(1);
                    }

                }

            }

            node_data first2 = new_g.getV().iterator().next();
            Queue<node_data> queue2 = new LinkedList<>();
            queue2.add(first2);
            while (!queue2.isEmpty()) {
                first2 = queue2.poll();
                first2.setTag(2);
                for (edge_data s : new_g.getE(first2.getKey())) {
                    node_data check = new_g.getNode(s.getDest());
                    if (check.getTag() == 0) {
                        queue2.add(check);
                        s.setTag(1);
                    }
                }
            }


            for (node_data check : g.getV()) {
                if (check.getTag() == 0 || check.getTag() == 1)
                    return false;
            }
            for (node_data check : new_g.getV()) {
                if (check.getTag() == 0 || check.getTag() == 1)
                    return false;
            }
            if (queue.size() != queue2.size()) {
                return false;
            }
        }


            return true;
        }

    private void change_graph_to_unvisited() {//change all the info to false

        for (node_data node : g.getV()) {
            node.setInfo("");
        }
    }

    private void change_dist_to_infinity() {// change all the tage to infinity
        double dist = Double.MAX_VALUE;
        for (node_data node : g.getV()) {
            node.setWeight(dist);
        }
    }
    private void change_tag(){
        for (node_data node : g.getV()) {
            node.setTag(0);
        }
        }
    @Override
    public double shortestPathDist(int src, int dest) {
        node_data srcNode = g.getNode(src);
        node_data destNode = g.getNode(dest);
        if (g.getV().size() == 0 || g.getNode(src) == null || g.getNode(dest) == null) {
            return -1;
        }
        else if (src == dest) {
            return 0;
        }
        ShortPathCheck(src);
            return destNode.getWeight();

        }

    private void ShortPathCheck (int src){
            node_data srcNode = g.getNode(src);
            change_dist_to_infinity();
            change_graph_to_unvisited();
            change_tag();
            PriorityQueue<node_data> queue = new PriorityQueue<>();
            queue.add(srcNode);
            srcNode.setWeight(0);
            while (!queue.isEmpty()) {
                node_data first = queue.poll();
                if(!queue.contains(first)){
                first.setTag(1);
                for (edge_data n : g.getE(first.getKey())) {//check the first edges conecct
                    double weight = first.getWeight() + n.getWeight();
                    if (weight < g.getNode(n.getDest()).getWeight()&&g.getNode(n.getDest()).getWeight()==0) {
                        g.getNode(n.getDest()).setWeight(weight);
                        g.getNode(n.getDest()).setTag(1);
                        g.getNode(n.getDest()).setInfo("" + first.getKey());
                        queue.add(g.getNode(n.getDest()));
                    }
                }
                first.setTag(2);
            }
            }
    }

    @Override
    public List<node_data> shortestPath(int src, int dest) {
        return null;
    }

    /**
     * Saves this weighted (directed) graph to the given
     * file name - in JSON format
     * @param file - the file name (may include a relative path).
     * @return true - iff the file was successfully saved
     */
    @Override
    public boolean save(String file) throws IOException {
        Gson gson = new Gson();


        return false;
    }
    /**
     * This method load a graph to this graph algorithm.
     * if the file was successfully loaded - the underlying graph
     * of this class will be changed (to the loaded one), in case the
     * graph was not loaded the original graph should remain "as is".
     * @param file - file name of JSON file
     * @return true - iff the graph was successfully loaded.
     */
    @Override
    public boolean load(String file) {

        return false;
    }





}
